Mezcalomano Table 2 placeholders

These files are intentionally lightweight placeholders to unblock layout and deployment.
Replace them with final photography/hero crops when ready.

Notes:
- Files are exported as WebP and JPG for maximum compatibility.
- If your environment supports AVIF export, AVIF versions may also be included.
- Dimensions follow a 3:4 portrait format (mobile-first friendly).
